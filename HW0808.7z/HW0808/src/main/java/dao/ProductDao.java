package dao;

import java.util.List;

import model.Product;

public interface ProductDao {

	
	
	void addProduct(Product product);
	
	Product findById(int id);
	List <Product> findAll();
	Product findByProductNo(String productNo);
	
	 void update(Product product);
	 
	 
	 
	 void delete(int id);
		
	
	
	
	
}
