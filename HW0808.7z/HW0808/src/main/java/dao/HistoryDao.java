package dao;

import java.util.List;
import model.HistoryOrder;

public interface HistoryDao {

 
    void addHistory(HistoryOrder order);


    HistoryOrder findLatestByUser(String userName);
    

    List<HistoryOrder> findByUser(String userName);
    


    List<HistoryOrder> findAll();
}
