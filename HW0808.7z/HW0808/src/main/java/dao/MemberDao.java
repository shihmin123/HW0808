package dao;

import java.util.List;

import model.Member;

public interface MemberDao {
	
	//create
	void add(Member member);
	void add(String name, String username, String password, String address, String phone,String role);
	
	
	//read
	Member select(String username , String password);
	Member select(String username);
	List<Member> findAll();
	Member selectById(int id);
	
	//update 
	void update(Member member);
	
	
	
	
	//delete
	void delete(int id);
}
