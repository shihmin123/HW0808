package dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import dao.MemberDao;
import model.Member;

import util.DbConnection;

public class MemberDaoImpl implements MemberDao{

	public static void main(String[] args) {
		
		
	}
private static Connection conn =DbConnection.getDb();
	@Override
	public void add(Member member) {

		String sql = "insert into member(name,username,password,address,phone,role) "
				+ "values(?,?,?,?,?,?)";
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, member.getName());
			ps.setString(2, member.getUsername());
			ps.setString(3, member.getPassword());
			ps.setString(4, member.getAddress());
			ps.setString(5, member.getPhone());
			ps.setString(6, member.getRole());
			ps.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		}	
	}
	@Override
	public Member select(String username, String password) {
		String sql = "select * from member where username=? and password=?";
		Member member=null;
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1,username);
			ps.setString(2,password);
			ResultSet rs=ps.executeQuery();
			if(rs.next())
			{
				member=new Member();
				member.setId(rs.getInt("id"));
				member.setName(rs.getString("name"));
				member.setUsername(rs.getString("username"));
				member.setPassword(rs.getString("password"));
				member.setAddress(rs.getString("address"));
				member.setPhone(rs.getString("phone"));
				member.setRole(rs.getString("role"));
			}
			
		} catch (SQLException e) {

			e.printStackTrace();
		}
		return member;
	}

	@Override
	public Member select(String username) {
		Member member = null;
		String sql="Select * from member where username=?";
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1,username);
			ResultSet rs = ps.executeQuery();
			if(rs.next())
			{
				member=new Member();
				member.setId(rs.getInt("id"));
				member.setName(rs.getString("name"));
				member.setUsername(rs.getString("username"));
				member.setPassword(rs.getString("password"));
				member.setAddress(rs.getString("address"));
				member.setPhone(rs.getString("phone"));
				member.setRole(rs.getString("role"));
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		return member;
	}
	@Override
	public void add(String name, String username, String password, String address, String phone,String role) {
		String sql = "insert into member(name,username,password,address,phone,role) "
				+ "values(?,?,?,?,?,?)";
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, name);
			ps.setString(2, username);
			ps.setString(3, password);
			ps.setString(4, address);
			ps.setString(5, phone);
			ps.setString(6, role);
			ps.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	@Override
	public void update(Member member) {
		String sql = "UPDATE member SET name=?, username=?, password=?, address=?, phone=?, role=? WHERE id=?";
	    try (PreparedStatement ps = conn.prepareStatement(sql)) {
	        ps.setString(1, member.getName());
	        ps.setString(2, member.getUsername());
	        ps.setString(3, member.getPassword());
	        ps.setString(4, member.getAddress());
	        ps.setString(5, member.getPhone());
	        ps.setString(6, member.getRole());
	        ps.setInt(7, member.getId());
	        ps.executeUpdate();
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
		
	}
	@Override
	public void delete(int id) {
		String sql = "DELETE FROM member WHERE id=?";
	    try (PreparedStatement ps = conn.prepareStatement(sql)) {
	        ps.setInt(1, id);
	        ps.executeUpdate();
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	}
	@Override
	public List<Member> findAll() {
		List<Member> members = new ArrayList<>();
		String sql = "SELECT * FROM member";
	    try (PreparedStatement ps = conn.prepareStatement(sql);
	         ResultSet rs = ps.executeQuery()) {
	        while (rs.next()) {
	            Member member = new Member();
	            member.setId(rs.getInt("id"));
	            member.setName(rs.getString("name"));
	            member.setUsername(rs.getString("username"));
	            member.setPassword(rs.getString("password"));
	            member.setAddress(rs.getString("address"));
	            member.setPhone(rs.getString("phone"));
	            member.setRole(rs.getString("role"));
	            members.add(member);
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    return members;
	}
	@Override
	public Member selectById(int id) {
		String sql = "SELECT * FROM member WHERE id=?";
	    try (PreparedStatement ps = conn.prepareStatement(sql)) {
	        ps.setInt(1, id);
	        ResultSet rs = ps.executeQuery();
	        if (rs.next()) {
	            Member m = new Member();
	            m.setId(rs.getInt("id"));
	            m.setName(rs.getString("name"));
	            m.setUsername(rs.getString("username"));
	            m.setPassword(rs.getString("password"));
	            m.setAddress(rs.getString("address"));
	            m.setPhone(rs.getString("phone"));
	            m.setRole(rs.getString("role"));
	            return m;
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    return null;
	}

}
