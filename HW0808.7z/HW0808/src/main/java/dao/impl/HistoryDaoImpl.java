package dao.impl;

import dao.HistoryDao;
import model.HistoryOrder;
import util.DbConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;

import java.util.ArrayList;
import java.util.List;

public class HistoryDaoImpl implements HistoryDao {

    private static final Connection conn = DbConnection.getDb();


    static {
    	String ddl = "CREATE TABLE IF NOT EXISTS history_order (\n" +
                "    id INT AUTO_INCREMENT PRIMARY KEY,\n" +
                "    userName VARCHAR(50) NOT NULL,\n" +
                "    orderSummary TEXT NOT NULL,\n" +
                "    orderTime TIMESTAMP DEFAULT CURRENT_TIMESTAMP\n" +
                ")";
        try (PreparedStatement ps = conn.prepareStatement(ddl)) {
            ps.execute();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    @Override
    public void addHistory(HistoryOrder o) {
        String sql = "INSERT INTO history_order(userName, orderSummary, orderTime) VALUES (?, ?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, o.getUserName());
            ps.setString(2, o.getOrderSummary());
            ps.setTimestamp(3, Timestamp.valueOf(o.getOrderTime()));
            ps.execute();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    @Override
    public List<HistoryOrder> findByUser(String userName) {
        List<HistoryOrder> list = new ArrayList<>();
        String sql = "SELECT * FROM history_order WHERE userName = ? ORDER BY orderTime DESC";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, userName);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                list.add(mapRow(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }


    @Override
    public List<HistoryOrder> findAll() {
        List<HistoryOrder> list = new ArrayList<>();
        String sql = "SELECT * FROM history_order ORDER BY orderTime DESC";
        try (PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                list.add(mapRow(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }
    
    @Override
    public HistoryOrder findLatestByUser(String userName) {
        String sql = "SELECT * FROM history_order "
                   + "WHERE userName = ? ORDER BY orderTime DESC LIMIT 1";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, userName);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return mapRow(rs);     
        } catch (SQLException e) { e.printStackTrace(); }
        return null;
    }


    private HistoryOrder mapRow(ResultSet rs) throws SQLException {
        HistoryOrder o = new HistoryOrder();
        o.setId(rs.getInt("id"));
        o.setUserName(rs.getString("userName"));
        o.setOrderSummary(rs.getString("orderSummary"));
        o.setOrderTime(rs.getTimestamp("orderTime").toLocalDateTime());
        return o;
    }


	
}
