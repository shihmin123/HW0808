package dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import dao.ProductDao;
import model.Product;
import util.DbConnection;

public class ProductDaoImpl implements ProductDao{

	public static void main(String[] args) {
		//Product productno = new ProductDaoImpl().findByProductNo("UX-11");
	}
private static Connection conn = DbConnection.getDb();
	@Override
	public void addProduct(Product product) {
		String sql = "insert into products(productNo,productName,productPrice) "
				+ "value(?,?,?)";
		try {
			PreparedStatement ps  = conn.prepareStatement(sql);
			ps.setString(1, product.getProductNo());
			ps.setString(2, product.getProductName());
			ps.setInt(3, product.getProductPrice());
			ps.execute();
			
		} catch (SQLException e) {

			e.printStackTrace();
		}
		
	}

	@Override
	public Product findById(int id) {
		Product product=null;
		String sql = "select *from products where id =?";
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setInt(1, id);
			ResultSet rs = ps.executeQuery();
			if(rs.next())
			{
				product = new Product();
	            product.setId(rs.getInt("id"));
	            product.setProductNo(rs.getString("productNo"));
	            product.setProductName(rs.getString("productName"));
	            product.setProductPrice(rs.getInt("productPrice"));
	                
			}
		} catch (SQLException e) {

			e.printStackTrace();
		}
		return product;
	}

	@Override
	public List<Product> findAll() {
		List<Product> list= new ArrayList();
		String sql = "select * from products";
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			while(rs.next())
			{
				
				Product product = new Product();
	            product.setId(rs.getInt("id"));
	            product.setProductNo(rs.getString("productNo"));
	            product.setProductName(rs.getString("productName"));
	            product.setProductPrice(rs.getInt("productPrice"));
	            list.add(product);
			}
			
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return list;
	}

	@Override
	public void update(Product product) {
		String sql = "UPDATE products SET productNo=?, productName=?, productPrice=? WHERE id=?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
        	ps.setString(1, product.getProductNo());
        	ps.setString(2, product.getProductName());
        	ps.setInt(3, product.getProductPrice());
        	ps.setInt(4, product.getId());
        	ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
	}

	@Override
	public void delete(int id) {
		 String sql = "delete from products where id=?";
	        try (PreparedStatement ps = conn.prepareStatement(sql)) {
	            ps.setInt(1, id);
	            ps.executeUpdate();
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
		
	}

	@Override
	public Product findByProductNo(String productNo) {
		Product product = null;
	    String sql = "SELECT * FROM products WHERE productNo = ?";
	    try {
	        PreparedStatement ps = conn.prepareStatement(sql);
	        ps.setString(1, productNo);
	        ResultSet rs = ps.executeQuery();
	        if (rs.next()) {
	            product = new Product();
	            product.setId(rs.getInt("id"));
	            product.setProductNo(rs.getString("productNo"));
	            product.setProductName(rs.getString("productName"));
	            product.setProductPrice(rs.getInt("productPrice"));
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    return product;
	}

}
