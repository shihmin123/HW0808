package controller;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import controller.member.AddMember;
import controller.member.AdminMain;
import controller.member.AdminMemberManagement;
import controller.member.MemberMain;
import controller.member.ShoppingMain;
import model.Member;
import service.impl.MemberServiceImpl;
import util.TimeUtil;
import util.Tool;
import service.MemberService;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JPasswordField;
import java.awt.Font;

public class Login extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField username;
	private JPasswordField passwordField;
	private MemberService memberService = new MemberServiceImpl();
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login frame = new Login();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Login() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("username");
		lblNewLabel.setFont(new Font("Bookman Old Style", Font.PLAIN, 20));
		lblNewLabel.setBounds(10, 91, 111, 24);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("password");
		lblNewLabel_1.setFont(new Font("Bookman Old Style", Font.PLAIN, 20));
		lblNewLabel_1.setBounds(10, 160, 95, 25);
		contentPane.add(lblNewLabel_1);
		
		username = new JTextField();
		username.setBounds(131, 94, 96, 21);
		contentPane.add(username);
		username.setColumns(10);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(131, 166, 96, 22);
		contentPane.add(passwordField);
		JButton login = new JButton("登入");
		login.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				String UserName =username.getText().trim();
				String Password = new String(((JPasswordField) passwordField).getPassword());
				Member member = memberService.login(UserName, Password);
				if (member != null) {
					Tool.saveFile(member,"member.txt");
				
					String role = member.getRole();
				
				
				if ("admin".equalsIgnoreCase(role)) {
					 JOptionPane.showMessageDialog(Login.this,"登入成功！即將進入管理者介面","成功", JOptionPane.INFORMATION_MESSAGE);
					 AdminMain adminMain = new AdminMain(); 
					 adminMain.setVisible(true);
					 dispose();
				}else if("user".equalsIgnoreCase(role))
				{
					JOptionPane.showMessageDialog(Login.this, "登入成功！即將前往購物頁面", "成功", JOptionPane.INFORMATION_MESSAGE);
					MemberMain memberMain = new MemberMain();
					memberMain.setVisible(true);
					dispose();
					}
				} else
				{
					int result = JOptionPane.showConfirmDialog(
						    Login.this, 
						    "登入失敗，是否前往註冊？", 
						    "登入失敗", 
						    JOptionPane.YES_NO_OPTION, 
						    JOptionPane.QUESTION_MESSAGE);
					if (result == JOptionPane.YES_OPTION) {  
					    AddMember addmember = new AddMember();
					    addmember.setVisible(true);
					    dispose();
					} else if (result == JOptionPane.NO_OPTION) { 
					    JOptionPane.showMessageDialog(Login.this, "請重新嘗試登入", "提示", JOptionPane.INFORMATION_MESSAGE);
					} else if (result == JOptionPane.CANCEL_OPTION || result == JOptionPane.CLOSED_OPTION) {  
					    JOptionPane.showMessageDialog(Login.this, "已取消操作", "提示", JOptionPane.WARNING_MESSAGE);
					}
				}
			}
		});
		login.setBounds(301, 96, 87, 23);
		contentPane.add(login);
		
		JButton register = new JButton("註冊");
		register.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				AddMember addmember= new AddMember();
			    addmember.setVisible(true);
			    dispose();
			}
		});
		register.setBounds(301, 165, 87, 23);
		contentPane.add(register);
		
		JLabel time = new JLabel("");
		time.setFont(new Font("Arial Black", Font.PLAIN, 21));
		time.setBounds(23, 10, 302, 49);
		contentPane.add(time);
		 TimeUtil.startClock(time);
		

	}
}
