package controller.product;

import java.awt.EventQueue;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import controller.member.AdminMain;
import model.Product;
import service.ProductUserService;
import service.impl.ProductUserServiceImpl;
import util.TableUtil;

import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;

public class ProductManagement extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTable memberTable;
	private DefaultTableModel tableModel;
	private final ProductUserService productService = new ProductUserServiceImpl();

	public static void main(String[] args) {
		EventQueue.invokeLater(() -> {
			try {
				ProductManagement frame = new ProductManagement();
				frame.setVisible(true);
			} catch (Exception e) {
				e.printStackTrace();
			}
		});
	}

	public ProductManagement() {
		setTitle("商品管理 - 所有商品清單");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 483, 386);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblGQup = new JLabel("商品清單", SwingConstants.LEFT);
		lblGQup.setFont(new Font("微軟正黑體", Font.BOLD, 24));
		lblGQup.setBounds(171, 28, 96, 33);
		contentPane.add(lblGQup);

		String[] columnNames = { "ID", "商品編號", "商品名稱", "商品價格" };
		tableModel = new DefaultTableModel(columnNames, 0);
		memberTable = new JTable(tableModel);
		JScrollPane scrollPane = new JScrollPane(memberTable);
		scrollPane.setBounds(10, 71, 426, 190);
		contentPane.add(scrollPane);

		JButton btnUpdate = new JButton("修改");
		btnUpdate.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				int selectedRow = memberTable.getSelectedRow();
				if (selectedRow == -1) {
					JOptionPane.showMessageDialog(ProductManagement.this, "請先選擇要修改的商品。", "提示",
							JOptionPane.WARNING_MESSAGE);
					return;
				}
				int id = (int) tableModel.getValueAt(selectedRow, 0);
				String no = (String) tableModel.getValueAt(selectedRow, 1);
				String name = (String) tableModel.getValueAt(selectedRow, 2);
				int price = (int) tableModel.getValueAt(selectedRow, 3);

				Product product = new Product(id, no, name, price);
				EditProductFrame editFrame = new EditProductFrame(product, updated -> {
					productService.updateProduct(updated);
					TableUtil.loadProductDataToTable(tableModel, productService);
				});
				editFrame.setVisible(true);
			}
		});
		btnUpdate.setBounds(119, 273, 87, 23);
		contentPane.add(btnUpdate);

		JButton btnDelete = new JButton("刪除");
		btnDelete.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				int selectedRow = memberTable.getSelectedRow();
				if (selectedRow == -1) {
					JOptionPane.showMessageDialog(ProductManagement.this, "請先選擇要刪除的商品。", "提示",
							JOptionPane.WARNING_MESSAGE);
					return;
				}

				int confirm = JOptionPane.showConfirmDialog(ProductManagement.this, "確定要刪除該商品嗎？", "確認刪除",
						JOptionPane.YES_NO_OPTION);

				if (confirm == JOptionPane.YES_OPTION) {
					int id = (int) tableModel.getValueAt(selectedRow, 0);
					productService.deleteProduct(id);
					TableUtil.loadProductDataToTable(tableModel, productService);
				}
			}
		});
		btnDelete.setBounds(233, 273, 87, 23);
		contentPane.add(btnDelete);

		JButton btnBack = new JButton("返回");
		btnBack.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				AdminMain adminMain = new AdminMain();
				adminMain.setVisible(true);
				dispose();
			}
		});
		btnBack.setBounds(349, 273, 87, 23);
		contentPane.add(btnBack);

		JButton btnAdd = new JButton("新增");
		btnAdd.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				Product product = new Product();
				EditProductFrame editFrame = new EditProductFrame(product, added -> {
					productService.addProduct(added);
					TableUtil.loadProductDataToTable(tableModel, productService);
				});
				editFrame.setVisible(true);
			}
		});
		btnAdd.setBounds(10, 273, 87, 23);
		contentPane.add(btnAdd);
		
		JButton btnNewButton = new JButton("篩選");
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				 String input = JOptionPane.showInputDialog(ProductManagement.this, "請輸入完整商品編號（精準查詢）");
			        if (input != null && !input.trim().isEmpty()) {
			            Product result = productService.getProductByNo(input.trim());
			            tableModel.setRowCount(0); 
			            if (result != null) {
			                Object[] row = {
			                    result.getId(),
			                    result.getProductNo(),
			                    result.getProductName(),
			                    result.getProductPrice()
			                };
			                tableModel.addRow(row);
			            } else {
			                JOptionPane.showMessageDialog(ProductManagement.this, "查無此商品編號！", "查詢結果", JOptionPane.INFORMATION_MESSAGE);
			            }
			        }
			}
		});
		btnNewButton.setBounds(349, 24, 87, 37);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("重整");
		btnNewButton_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				TableUtil.loadProductDataToTable(tableModel, productService);
			}
		});
		btnNewButton_1.setBounds(10, 28, 87, 33);
		contentPane.add(btnNewButton_1);


		TableUtil.loadProductDataToTable(tableModel, productService);
	}
}
