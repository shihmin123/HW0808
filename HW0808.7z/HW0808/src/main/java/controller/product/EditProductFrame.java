package controller.product;

import model.Product;

import java.util.function.Consumer;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class EditProductFrame extends JFrame {
    private JTextField tfNo;
    private JTextField tfName;
    private JTextField tfPrice;

    public EditProductFrame(Product product, Consumer<Product> onSave) {
        setTitle("修改商品資料");
        setSize(350, 250);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        getContentPane().setLayout(null);

        JLabel lblNo = new JLabel("商品編號:");
        lblNo.setBounds(30, 30, 80, 25);
        getContentPane().add(lblNo);

        tfNo = new JTextField(product.getProductNo());
        tfNo.setBounds(120, 30, 160, 25);
        getContentPane().add(tfNo);

        JLabel lblName = new JLabel("商品名稱:");
        lblName.setBounds(30, 70, 80, 25);
        getContentPane().add(lblName);

        tfName = new JTextField(product.getProductName());
        tfName.setBounds(120, 70, 160, 25);
        getContentPane().add(tfName);

        JLabel lblPrice = new JLabel("商品價格:");
        lblPrice.setBounds(30, 110, 80, 25);
        getContentPane().add(lblPrice);

        tfPrice = new JTextField(String.valueOf(product.getProductPrice()));
        tfPrice.setBounds(120, 110, 160, 25);
        getContentPane().add(tfPrice);

        JButton btnSave = new JButton("儲存");
        btnSave.addMouseListener(new MouseAdapter() {
        	@Override
        	public void mouseClicked(MouseEvent e) {
        		try {
                    product.setProductNo(tfNo.getText().trim());
                    product.setProductName(tfName.getText().trim());
                    product.setProductPrice(Integer.parseInt(tfPrice.getText().trim()));
                    onSave.accept(product); 
                    dispose();
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(EditProductFrame.this, "價格請輸入正整數", "錯誤", JOptionPane.ERROR_MESSAGE);
                }
        	}
        });
        btnSave.setBounds(120, 160, 80, 30);
        getContentPane().add(btnSave);
    }
}