package controller.porder;

import dao.HistoryDao;
import service.HistoryService;
import util.ExportOrderUtil;
import util.OrderUtil;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.print.PrinterException;



import controller.member.MemberMain;


public class OutputOrder extends JFrame {

    private static final long serialVersionUID = 1L;
    private JTextArea orderSummaryArea = new JTextArea();
    

    public OutputOrder(HistoryService historyService, String username) {

        setTitle("訂單明細");
        setBounds(100, 100, 320, 450);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        JPanel cp = new JPanel(null);
        setContentPane(cp);

        orderSummaryArea.setBounds(10, 10, 285, 300);
        orderSummaryArea.setEditable(false);
        cp.add(orderSummaryArea);

        JButton exportPDF = new JButton("Export PDF");
        exportPDF.addMouseListener(new MouseAdapter() {
        	@Override
        	public void mouseClicked(MouseEvent e) {
        		try {
					orderSummaryArea.print();
				} catch (PrinterException e1) {
					e1.printStackTrace();
				}
        	}
        });
        exportPDF.setBounds(10, 330, 135, 25);
        cp.add(exportPDF);

        JButton exportExcel = new JButton("Export Excel");
        exportExcel.addMouseListener(new MouseAdapter() {
        	@Override
        	public void mouseClicked(MouseEvent e) {
        		ExportOrderUtil.exportToExcel(orderSummaryArea, OutputOrder.this);
        	}
        });
        exportExcel.setBounds(160, 330, 135, 25);
        cp.add(exportExcel);
        
        JButton backMemberMain = new JButton("返回");
        backMemberMain.addMouseListener(new MouseAdapter() {
        	@Override
        	public void mouseClicked(MouseEvent e) {
        		MemberMain memberMain = new MemberMain();
        		memberMain.setVisible(true);
        		dispose();
        	}
        });
        backMemberMain.setBounds(10, 376, 135, 25);
        cp.add(backMemberMain);
        OrderUtil.showLatestOrderToTextArea(historyService, username, orderSummaryArea);
    }
}
