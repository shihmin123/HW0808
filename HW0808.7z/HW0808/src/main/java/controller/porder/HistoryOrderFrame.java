package controller.porder;

import model.Member;
import util.ExportOrderUtil;
import util.TableUtil;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import java.awt.FlowLayout;

import controller.member.AdminMain;
import controller.member.MemberMain;
import service.HistoryService;
import service.impl.HistoryServiceImpl;

import java.awt.BorderLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class HistoryOrderFrame extends JFrame {

    private static final long serialVersionUID = 1L;
    private JTable table = new JTable();
    private DefaultTableModel model;
    private HistoryService historyService = new HistoryServiceImpl();

    public HistoryOrderFrame(Member currentUser) {
        setTitle("訂單查詢");
        setBounds(100, 100, 789, 514);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        JPanel cp = new JPanel(new BorderLayout(5, 5));
        cp.setBorder(new EmptyBorder(10, 10, 10, 10));
        setContentPane(cp);

        String[] cols = {"ID", "User", "OrderTime", "OrderSummary", "Total"};
        model = new DefaultTableModel(cols, 0) {
            @Override
            public boolean isCellEditable(int r, int c) {
                return false;
            }
        };
        table.setModel(model);
        table.setRowHeight(24);
        JScrollPane scrollPane = new JScrollPane(table);
        cp.add(scrollPane, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        cp.add(buttonPanel, BorderLayout.SOUTH);

        JButton exportPDFButton = new JButton("Export PDF");
        exportPDFButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                try {
                    table.print();
                } catch (Exception ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(
                            HistoryOrderFrame.this,
                            "列印失敗：" + ex.getMessage(),
                            "錯誤",
                            JOptionPane.ERROR_MESSAGE
                    );
                }
            }
        });
        
        JButton selcetBtn = new JButton("篩選");
        selcetBtn.addMouseListener(new MouseAdapter() {
        	@Override
        	public void mouseClicked(MouseEvent e) {
        		 String username = JOptionPane.showInputDialog(HistoryOrderFrame.this, "請輸入使用者帳號（username）");
        	        if (username != null && !username.trim().isEmpty()) {
        	            TableUtil.loadHistoryOrderDataToTableByUsername(model, username.trim(), historyService);
        	        }
        	    
        
        		
        	}
        });
        
        JButton reset = new JButton("重整");
        reset.setVisible(false);
        reset.addMouseListener(new MouseAdapter() {
        	@Override
        	public void mouseClicked(MouseEvent e) {
        		if ("admin".equalsIgnoreCase(currentUser.getRole())) {
                    TableUtil.loadAllHistoryOrdersToTable(model, historyService);
                } else {
                    TableUtil.loadHistoryOrderDataToTable(model, currentUser, historyService);
                }
        	}
        });
        buttonPanel.add(reset);
        buttonPanel.add(selcetBtn);
        buttonPanel.add(exportPDFButton);
        selcetBtn.setVisible(false);
        if ("admin".equalsIgnoreCase(currentUser.getRole())) {
        	selcetBtn.setVisible(true);
        	reset.setVisible(true);
        }

        JButton exportExcelButton = new JButton("Export Excel");
        exportExcelButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                ExportOrderUtil.exportTableToExcel(table, HistoryOrderFrame.this);
            }
        });
        buttonPanel.add(exportExcelButton);

        JButton backButton = new JButton("返回");
        backButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
            	 String role = currentUser.getRole();
                 if ("admin".equalsIgnoreCase(role)) {
                     new AdminMain().setVisible(true);
                 } else {
                     new MemberMain().setVisible(true);
                 }
                 dispose();
            }
        });
        buttonPanel.add(backButton);


        TableUtil.loadHistoryOrderDataToTable(model, currentUser, historyService);
        TableUtil.adjustTableColumnWidths(table);
    }
}
