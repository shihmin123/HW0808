package controller.member;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.time.LocalDateTime;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import controller.porder.OutputOrder;
import model.HistoryOrder;
import model.Member;
import service.HistoryService;
import service.ProductUserService;
import service.impl.HistoryServiceImpl;
import service.impl.ProductUserServiceImpl;
import util.TableUtil;
import util.Tool;

import javax.swing.JOptionPane;

public class ShoppingMain extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;

    private JTable productTable;
    private DefaultTableModel tableModel;

    private final HistoryService historyService = new HistoryServiceImpl();
    private final ProductUserService productService = new ProductUserServiceImpl();
    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                ShoppingMain frame = new ShoppingMain();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public ShoppingMain() {
    	
    	
    	
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 481, 607);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JPanel panel = new JPanel();
        panel.setBackground(new Color(128, 128, 128));
        panel.setBounds(27, 46, 371, 98);
        contentPane.add(panel);
        panel.setLayout(null);

        JTextArea orderSummary = new JTextArea();
        orderSummary.setBounds(28, 331, 415, 134);
        contentPane.add(orderSummary);

        JLabel lblNewLabel = new JLabel("歡迎來到戰鬥陀螺購物平台");
        lblNewLabel.setBounds(10, 25, 351, 49);
        panel.add(lblNewLabel);
        lblNewLabel.setFont(new Font("微软雅黑", Font.PLAIN, 29));
        lblNewLabel.setVisible(true);
        new javax.swing.Timer(3000, e -> {
            lblNewLabel.setVisible(false);
            panel.setVisible(false);
            ((javax.swing.Timer) e.getSource()).stop();
        }).start();

        JLabel userName = new JLabel("");
        userName.setFont(new Font("微软雅黑", Font.PLAIN, 21));
        userName.setBounds(27, 10, 206, 26);
        contentPane.add(userName);
        Member m = (Member) Tool.readFile("member.txt");
        String show = m.getName();
        userName.setText(show + "歡迎您");

        String[] columnNames = { "商品編號", "商品名稱", "商品價格" };
        tableModel = new DefaultTableModel(columnNames, 0);
        productTable = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(productTable);
        productTable.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int selectedRow = productTable.getSelectedRow();
                if (selectedRow != -1) {
                    String productNo = tableModel.getValueAt(selectedRow, 0).toString();
                    String productName = tableModel.getValueAt(selectedRow, 1).toString();
                    int productPrice = Integer.parseInt(tableModel.getValueAt(selectedRow, 2).toString());

                    String quantityStr = JOptionPane.showInputDialog(ShoppingMain.this,
                            "請輸入購買數量：", "購買 " + productName, JOptionPane.PLAIN_MESSAGE);
                    if (quantityStr != null && !quantityStr.isBlank()) {
                        try {
                            int quantity = Integer.parseInt(quantityStr);
                            if (quantity <= 0)
                                throw new NumberFormatException();

                            int total = productPrice * quantity;
                            orderSummary.append(
                                    "商品: " + productName + "，數量: " + quantity + "，單價: " + productPrice + "，總計: " + total
                                            + "\n");

                        } catch (NumberFormatException ex) {
                            JOptionPane.showMessageDialog(ShoppingMain.this, "請輸入有效的整數數量", "錯誤",
                                    JOptionPane.ERROR_MESSAGE);
                        }
                    }
                }
            }
        });
        scrollPane.setBounds(23, 162, 420, 134);
        contentPane.add(scrollPane);

        JButton btnNewButton = new JButton("結帳");
        btnNewButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                String summary = orderSummary.getText().trim();
                if (summary.isBlank()) {
                    JOptionPane.showMessageDialog(ShoppingMain.this, "目前沒有選購任何商品！", "提示",
                            JOptionPane.WARNING_MESSAGE);
                    return;
                }

                Member member = (Member) Tool.readFile("member.txt");
                String uName = member.getUsername();

                HistoryOrder order = new HistoryOrder();
                order.setUserName(uName);
                order.setOrderSummary(summary);
                order.setOrderTime(LocalDateTime.now());
                historyService.addHistory(order);

                JOptionPane.showMessageDialog(ShoppingMain.this, "結帳完成！訂單已存入歷史紀錄。", "成功",
                        JOptionPane.INFORMATION_MESSAGE);

                orderSummary.setText("");

                OutputOrder output = new OutputOrder(historyService, uName);
                output.setVisible(true);
                dispose();
            }
        });
        btnNewButton.setBounds(36, 499, 97, 26);
        contentPane.add(btnNewButton);

        JButton backMemberMain = new JButton("返回");
        backMemberMain.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                MemberMain memberMain = new MemberMain();
                memberMain.setVisible(true);
                dispose();
            }
        });
        backMemberMain.setBounds(292, 499, 106, 25);
        contentPane.add(backMemberMain);

        TableUtil.loadProductDataToTableThreeColumns(tableModel, productService);
    }
}