package controller.member;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import model.Member;
import service.MemberService;
import service.impl.MemberServiceImpl;
import util.TableUtil;

import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class AdminMemberManagement extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTable memberTable;
    private DefaultTableModel tableModel;

    private MemberService memberService = new MemberServiceImpl();

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                AdminMemberManagement frame = new AdminMemberManagement();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public AdminMemberManagement() {
        setTitle("管理者後台 - 所有會員資料");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 475, 382);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel title = new JLabel("會員清單", SwingConstants.LEFT);
        title.setBounds(165, 10, 96, 33);
        title.setFont(new Font("微軟正黑體", Font.BOLD, 24));
        contentPane.add(title);

        String[] columnNames = {"ID", "姓名", "帳號", "密碼", "地址", "電話", "角色"};

        tableModel = new DefaultTableModel(columnNames, 0);
        memberTable = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(memberTable);
        scrollPane.setBounds(10, 53, 439, 198);
        contentPane.add(scrollPane, BorderLayout.CENTER);

        JButton editButton = new JButton("修改");
        editButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int selectedRow = memberTable.getSelectedRow();
                if (selectedRow == -1) {
                    JOptionPane.showMessageDialog(AdminMemberManagement.this, "請先選擇一位會員。", "提示", JOptionPane.WARNING_MESSAGE);
                    return;
                }

                Member member = new Member();
                member.setId((int) tableModel.getValueAt(selectedRow, 0));
                member.setName((String) tableModel.getValueAt(selectedRow, 1));
                member.setUsername((String) tableModel.getValueAt(selectedRow, 2));
                member.setPassword((String) tableModel.getValueAt(selectedRow, 3));
                member.setAddress((String) tableModel.getValueAt(selectedRow, 4));
                member.setPhone((String) tableModel.getValueAt(selectedRow, 5));
                member.setRole((String) tableModel.getValueAt(selectedRow, 6));

                EditMemberFrame editFrame = new EditMemberFrame(member, () -> {
                    // 用 MemberService 更新會員
                    memberService.updateMember(member);
                    // 更新表格資料
                    TableUtil.loadMemberDataToTable(tableModel, memberService);
                });
                editFrame.setVisible(true);
            }
        });
        editButton.setBounds(10, 275, 104, 33);
        contentPane.add(editButton);

        JButton deleteButton = new JButton("刪除");
        deleteButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int selectedRow = memberTable.getSelectedRow();
                if (selectedRow == -1) {
                    JOptionPane.showMessageDialog(AdminMemberManagement.this, "請先選擇要刪除的會員。", "提示", JOptionPane.WARNING_MESSAGE);
                    return;
                }
                String role = (String) tableModel.getValueAt(selectedRow, 6);
                if ("admin".equalsIgnoreCase(role)) {
                    JOptionPane.showMessageDialog(AdminMemberManagement.this, "管理者帳號無法刪除！", "禁止操作", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                int confirm = JOptionPane.showConfirmDialog(AdminMemberManagement.this, "確定要刪除這位會員嗎？", "確認刪除", JOptionPane.YES_NO_OPTION);
                if (confirm == JOptionPane.YES_OPTION) {
                    int id = (int) tableModel.getValueAt(selectedRow, 0);
                    memberService.deleteMember(id);
                    TableUtil.loadMemberDataToTable(tableModel, memberService);
                    JOptionPane.showMessageDialog(AdminMemberManagement.this, "會員已刪除。", "完成", JOptionPane.INFORMATION_MESSAGE);
                }
            }
        });
        deleteButton.setBounds(116, 275, 104, 33);
        contentPane.add(deleteButton);

        JButton btnReturn = new JButton("返回");
        btnReturn.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                AdminMain adminMain = new AdminMain();
                adminMain.setVisible(true);
                dispose();
            }
        });
        btnReturn.setBounds(345, 275, 104, 33);
        contentPane.add(btnReturn);

        JButton btnFilter = new JButton("篩選");
        btnFilter.addMouseListener(new MouseAdapter() {
        	@Override
        	public void mouseClicked(MouseEvent e) {
        		 String username = JOptionPane.showInputDialog(AdminMemberManagement.this, "請輸入要查詢的帳號（username）：");

        	        if (username != null && !username.isBlank()) {
        	            Member found = memberService.findByUsername(username);
        	            tableModel.setRowCount(0); 

        	            if (found != null) {
        	                Object[] rowData = {
        	                    found.getId(),
        	                    found.getName(),
        	                    found.getUsername(),
        	                    found.getPassword(),
        	                    found.getAddress(),
        	                    found.getPhone(),
        	                    found.getRole()
        	                };
        	                tableModel.addRow(rowData);
        	            } else {
        	                JOptionPane.showMessageDialog(AdminMemberManagement.this, "找不到該帳號的會員", "查無資料", JOptionPane.INFORMATION_MESSAGE);
        	            }
        	        }
        	    
        	}
        });
        btnFilter.setBounds(230, 275, 104, 33);
        contentPane.add(btnFilter);
        
        JButton reset = new JButton("重整");
        reset.addMouseListener(new MouseAdapter() {
        	@Override
        	public void mouseClicked(MouseEvent e) {
        		TableUtil.loadMemberDataToTable(tableModel, memberService);
        	}
        });
        reset.setBounds(10, 10, 104, 33);
        contentPane.add(reset);


        TableUtil.loadMemberDataToTable(tableModel, memberService);
    }
}