package controller.member;

import model.Member;
import service.MemberService;
import service.impl.MemberServiceImpl;
import util.Tool;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class EditMyself extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField tfName, tfPassword, tfAddress, tfPhone;

    private final MemberService memberService = new MemberServiceImpl();
    private Member currentUser;

    public EditMyself(Member user) {
        this.currentUser = user;
        initUI();
        loadData();
    }

    private void initUI() {
        setTitle("修改個人資料");
        setBounds(100, 100, 450, 460);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        contentPane = new JPanel(null);
        contentPane.setBorder(new EmptyBorder(10, 10, 10, 10));
        setContentPane(contentPane);

        Font f = new Font("微軟正黑體", Font.PLAIN, 19);

        JLabel l1 = new JLabel("姓名:");
        l1.setFont(f);
        l1.setBounds(40, 60, 90, 30);
        contentPane.add(l1);

        JLabel l2 = new JLabel("Password:");
        l2.setFont(f);
        l2.setBounds(40, 120, 100, 30);
        contentPane.add(l2);

        JLabel l3 = new JLabel("Address:");
        l3.setFont(f);
        l3.setBounds(40, 180, 90, 30);
        contentPane.add(l3);

        JLabel l4 = new JLabel("Phone:");
        l4.setFont(f);
        l4.setBounds(40, 240, 90, 30);
        contentPane.add(l4);

        tfName = new JTextField();
        tfName.setBounds(150, 60, 180, 28);
        contentPane.add(tfName);

        tfPassword = new JTextField();
        tfPassword.setBounds(150, 120, 180, 28);
        contentPane.add(tfPassword);

        tfAddress = new JTextField();
        tfAddress.setBounds(150, 180, 180, 28);
        contentPane.add(tfAddress);

        tfPhone = new JTextField();
        tfPhone.setBounds(150, 240, 180, 28);
        contentPane.add(tfPhone);

        JButton btnUpdate = new JButton("修改");
        btnUpdate.addMouseListener(new MouseAdapter() {
        	@Override
        	public void mouseClicked(MouseEvent e) {
        		if (tfName.getText().isBlank() || tfPassword.getText().isBlank()) {
                    JOptionPane.showMessageDialog(EditMyself.this, "姓名與密碼不可空白！", "錯誤", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                currentUser.setName(tfName.getText().trim());
                currentUser.setPassword(tfPassword.getText().trim());
                currentUser.setAddress(tfAddress.getText().trim());
                currentUser.setPhone(tfPhone.getText().trim());

                memberService.updateMember(currentUser);

                Tool.writeFile("member.txt", currentUser);

                JOptionPane.showMessageDialog(EditMyself.this, "更新成功！", "完成", JOptionPane.INFORMATION_MESSAGE);
                MemberMain main = new MemberMain();
                main.setVisible(true);
                dispose();
        	}
        });
        btnUpdate.setFont(new Font("微軟正黑體", Font.PLAIN, 20));
        btnUpdate.setBounds(40, 301, 100, 45);
        contentPane.add(btnUpdate);

        JButton btnBack = new JButton("返回");
        btnBack.addMouseListener(new MouseAdapter() {
        	@Override
        	public void mouseClicked(MouseEvent e) {
        		MemberMain memberMain = new MemberMain();
        		memberMain.setVisible(true);
        		dispose();
        	}
        });
        btnBack.setFont(new Font("微軟正黑體", Font.PLAIN, 20));
        btnBack.setBounds(230, 301, 100, 45);
        contentPane.add(btnBack);


    }

    private void loadData() {
        tfName.setText(currentUser.getName());
        tfPassword.setText(currentUser.getPassword());
        tfAddress.setText(currentUser.getAddress());
        tfPhone.setText(currentUser.getPhone());
    }

    
    
}