package controller.member;

import model.Member;

import javax.swing.*;
import java.awt.*;
import java.util.function.Consumer;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class EditMemberFrame extends JFrame {

    private Member member;
    private Runnable onUpdate;

    public EditMemberFrame(Member member, Runnable onUpdate) {
        this.member = member;
        this.onUpdate = onUpdate;

        setTitle("修改會員資料");
        setSize(400, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel panel = new JPanel(new GridLayout(8, 2, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        JTextField nameField = new JTextField(member.getName());
        JTextField usernameField = new JTextField(member.getUsername());
        JTextField passwordField = new JTextField(member.getPassword());
        JTextField addressField = new JTextField(member.getAddress());
        JTextField phoneField = new JTextField(member.getPhone());
        JTextField roleField = new JTextField(member.getRole());

        panel.add(new JLabel("姓名"));
        panel.add(nameField);
        panel.add(new JLabel("帳號"));
        panel.add(usernameField);
        panel.add(new JLabel("密碼"));
        panel.add(passwordField);
        panel.add(new JLabel("地址"));
        panel.add(addressField);
        panel.add(new JLabel("電話"));
        panel.add(phoneField);
        panel.add(new JLabel("角色"));
        panel.add(roleField);

        JButton saveBtn = new JButton("儲存");
        saveBtn.addMouseListener(new MouseAdapter() {
        	@Override
        	public void mouseClicked(MouseEvent e) {
        		member.setName(nameField.getText());
                member.setUsername(usernameField.getText());
                member.setPassword(passwordField.getText());
                member.setAddress(addressField.getText());
                member.setPhone(phoneField.getText());
                member.setRole(roleField.getText());

                if (onUpdate != null) {
                    onUpdate.run();
                }
                JOptionPane.showMessageDialog(EditMemberFrame.this, "會員資料已更新！");
                dispose();
        	}
        });
        JButton cancelBtn = new JButton("取消");
        cancelBtn.addMouseListener(new MouseAdapter() {
        	@Override
        	public void mouseClicked(MouseEvent e) {
        		dispose();
        	}
        });
        panel.add(saveBtn);
        panel.add(cancelBtn);

        getContentPane().add(panel);
    }
}
