package controller.member;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import controller.Login;
import model.Member;
import service.impl.MemberServiceImpl;
import service.MemberService;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JComboBox;

public class AddMember extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField name;
	private JTextField username;
	private JTextField password;
	private JTextField address;
	private JTextField phone;
	private MemberService memberService = new MemberServiceImpl();

	public static void main(String[] args) {
		EventQueue.invokeLater(() -> {
			try {
				AddMember frame = new AddMember();
				frame.setVisible(true);
			} catch (Exception e) {
				e.printStackTrace();
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public AddMember() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 425);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("姓名:");
		lblNewLabel.setBounds(48, 34, 46, 15);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("帳號:");
		lblNewLabel_1.setBounds(48, 92, 46, 15);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("密碼:");
		lblNewLabel_2.setBounds(48, 151, 46, 15);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("地址:");
		lblNewLabel_3.setBounds(48, 202, 46, 15);
		contentPane.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("手機:");
		lblNewLabel_4.setBounds(48, 247, 46, 15);
		contentPane.add(lblNewLabel_4);
		
		name = new JTextField();
		name.setBounds(129, 31, 96, 21);
		contentPane.add(name);
		name.setColumns(10);
		
		username = new JTextField();
		username.setBounds(129, 89, 96, 21);
		contentPane.add(username);
		username.setColumns(10);
		
		password = new JTextField();
		password.setBounds(129, 148, 96, 21);
		contentPane.add(password);
		password.setColumns(10);
		
		address = new JTextField();
		address.setBounds(129, 199, 96, 21);
		contentPane.add(address);
		address.setColumns(10);
		
		phone = new JTextField();
		phone.setBounds(129, 244, 96, 21);
		contentPane.add(phone);
		phone.setColumns(10);
		
		JLabel lblNewLabel_4_1 = new JLabel("使用者:");
		lblNewLabel_4_1.setBounds(48, 307, 46, 15);
		contentPane.add(lblNewLabel_4_1);
		
		String[] roles = {"user"};
		JComboBox<String> roleBox = new JComboBox<>(roles);
		roleBox.setBounds(129, 303, 96, 23);
		contentPane.add(roleBox);
		roleBox.setEnabled(false);
		
		JButton registerBtn = new JButton("註冊");
		registerBtn.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
			    String Name = name.getText().trim();
			    String UserName = username.getText().trim();
			    String Password = password.getText().trim();
			    String Address = address.getText().trim();
			    String Phone = phone.getText().trim();
			    String Role = roleBox.getSelectedItem().toString();
			    Member member = new Member(Name, UserName, Password, Address, Phone, Role);
			    
			    if (Name.isEmpty() || UserName.isEmpty() || Password.isEmpty() || Address.isEmpty() || Phone.isEmpty() || Role.isEmpty()) {
			        JOptionPane.showMessageDialog(
			           AddMember.this,
			           "請完整填寫所有欄位！",
			           "欄位未填寫",
			           JOptionPane.WARNING_MESSAGE);
			        return; 
			    }
			    	
			    if (memberService.addMember(member)) {
			    	JOptionPane.showMessageDialog(AddMember.this, "前往登入頁面", "註冊成功", JOptionPane.INFORMATION_MESSAGE );
			    } else {
			    	JOptionPane.showMessageDialog(AddMember.this, "帳號重複", "註冊失敗", JOptionPane.INFORMATION_MESSAGE );
			    }
			    
			    Login login = new Login();
			    login.setVisible(true);
			    dispose();
			}
		});
		registerBtn.setBounds(292, 74, 111, 51);
		contentPane.add(registerBtn);
		
		JButton returnbtn = new JButton("返回");
		returnbtn.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				Login login = new Login();
				login.setVisible(true);
				dispose();
			}
		});
		returnbtn.setBounds(292, 184, 111, 51);
		contentPane.add(returnbtn);
	}
}