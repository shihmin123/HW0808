package controller.member;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import controller.Login;
import controller.porder.HistoryOrderFrame;
import controller.product.ProductManagement;
import model.Member;
import util.Tool;

import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class AdminMain extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AdminMain frame = new AdminMain();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public AdminMain() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 464);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Administrator Interface");
		lblNewLabel.setFont(new Font("Gabriola", Font.PLAIN, 40));
		lblNewLabel.setBounds(58, 29, 317, 83);
		contentPane.add(lblNewLabel);
		
		JButton userlist = new JButton("使用者名單");
		userlist.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				AdminMemberManagement adminMemberManagement = new AdminMemberManagement();
				adminMemberManagement.setVisible(true);
				dispose();
			}
		});
		userlist.setFont(new Font("微软雅黑", Font.PLAIN, 20));
		userlist.setBounds(232, 115, 143, 67);
		contentPane.add(userlist);
		
		JButton productlist = new JButton("商品名單");
		productlist.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				ProductManagement productManagement = new ProductManagement();
				productManagement.setVisible(true);
				dispose();
			}
		});
		productlist.setFont(new Font("微软雅黑", Font.PLAIN, 20));
		productlist.setBounds(232, 192, 143, 60);
		contentPane.add(productlist);
		
		JButton queryHistoryOrder = new JButton("訂單查詢");
		queryHistoryOrder.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
		        Member current = (Member) Tool.readFile("member.txt");
		        HistoryOrderFrame frame = new HistoryOrderFrame(current);
		        frame.setVisible(true);
		        dispose();
			}
		});
		queryHistoryOrder.setFont(new Font("微软雅黑", Font.PLAIN, 20));
		queryHistoryOrder.setBounds(232, 262, 143, 60);
		contentPane.add(queryHistoryOrder);
		
		JLabel userName = new JLabel("New label");
		userName.setFont(new Font("微软雅黑", Font.PLAIN, 22));
		userName.setBounds(20, 85, 355, 27);
		contentPane.add(userName);
		Tool.displayWelcomeMessage(userName);
		
		JButton btnNewButton = new JButton("登出");
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				Login login = new Login();
				login.setVisible(true);
				dispose();
			}
		});
		btnNewButton.setFont(new Font("微软雅黑", Font.PLAIN, 20));
		btnNewButton.setBounds(232, 332, 143, 60);
		contentPane.add(btnNewButton);

	}
}
