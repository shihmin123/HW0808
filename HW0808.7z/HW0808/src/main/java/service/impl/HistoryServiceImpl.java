package service.impl;

import java.util.List;

import dao.HistoryDao;
import dao.impl.HistoryDaoImpl;
import model.HistoryOrder;
import service.HistoryService;

public class HistoryServiceImpl implements HistoryService {

    private final HistoryDao historyDao = new HistoryDaoImpl();

    @Override
    public void addHistory(HistoryOrder order) {
        historyDao.addHistory(order);
    }

    @Override
    public HistoryOrder getLatestOrderByUser(String userName) {
        return historyDao.findLatestByUser(userName);
    }

    @Override
    public List<HistoryOrder> getOrdersByUser(String userName) {
        return historyDao.findByUser(userName);
    }

    @Override
    public List<HistoryOrder> getAllOrders() {
        return historyDao.findAll();
    }

	

	
}