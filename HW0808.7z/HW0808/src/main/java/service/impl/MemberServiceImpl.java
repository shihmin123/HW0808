package service.impl;

import java.util.List;

import dao.impl.MemberDaoImpl;
import dao.MemberDao;
import model.Member;
import service.MemberService;

public class MemberServiceImpl implements MemberService{

	public static void main(String[] args) {
		
	}
private static MemberDao mdi= new MemberDaoImpl();
	@Override
	public boolean addMember(Member member) {
		boolean isUsernametrue=false;
		Member m = mdi.select(member.getUsername());
		if(m==null)
		{
			mdi.add(member);
			isUsernametrue=true;
		}
		return isUsernametrue;
	} 
	@Override
	public Member login(String username, String password) {
		
		return mdi.select(username,password);
	}
	@Override
	public void add(String name, String username, String password, String address, String phone, String role) {
		mdi.add(name, username, password, address, phone, role);
		
	}
	@Override
	public Member findByUsername(String username) {
		// TODO Auto-generated method stub
		return mdi.select(username);
	}
	@Override
	public Member findById(int id) {
		// TODO Auto-generated method stub
		return mdi.selectById(id);
	}
	@Override
	public List<Member> getAllMembers() {
		// TODO Auto-generated method stub
		return mdi.findAll();
	}
	@Override
	public void updateMember(Member member) {
		mdi.update(member);
		
	}
	@Override
	public void deleteMember(int id) {
		mdi.delete(id);
		
	}

}
