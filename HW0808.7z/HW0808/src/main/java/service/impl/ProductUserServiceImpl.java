package service.impl;

import java.util.List;

import dao.ProductDao;
import dao.impl.ProductDaoImpl;
import model.Product;
import service.ProductUserService;

public class ProductUserServiceImpl implements ProductUserService {

	public static void main(String[] args) {



	}
	private ProductDao productDao = new ProductDaoImpl();
	@Override
	public List<Product> getAllProducts() {

		 return productDao.findAll();
	}

	@Override
	public Product getProductById(int id) {

		return productDao.findById(id);
	}

	@Override
	public Product getProductByNo(String productNo) {

		return productDao.findByProductNo(productNo);
	}

	@Override
	public void addProduct(Product product) {
		productDao.addProduct(product);
		
	}

	@Override
	public void updateProduct(Product product) {
		productDao.update(product);
		
	}

	@Override
	public void deleteProduct(int id) {
		productDao.delete(id);
		
	}
	
}
