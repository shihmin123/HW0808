package service;

import java.util.List;
import model.HistoryOrder;

public interface HistoryService {

    void addHistory(HistoryOrder order);

    HistoryOrder getLatestOrderByUser(String userName);

    List<HistoryOrder> getOrdersByUser(String userName);
    
    List<HistoryOrder> getAllOrders();
}