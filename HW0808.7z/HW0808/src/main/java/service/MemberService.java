package service;

import java.util.List;

import model.Member;

public interface MemberService {
	//create
	boolean addMember(Member member);
	void add(String name, String username, String password, String address, String phone, String role);

    Member login(String username, String password);

    Member findByUsername(String username);

    Member findById(int id);

    List<Member> getAllMembers();

    void updateMember(Member member);

    void deleteMember(int id);
	
	
	
	
	
}
