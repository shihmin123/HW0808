package service;

import java.util.List;

import model.Product;

public interface ProductUserService {
	
	 void addProduct(Product product);
	
	
	 List<Product> getAllProducts();
	 Product getProductById(int id);
	 Product getProductByNo(String productNo);
	 
	 void updateProduct(Product product);
	    
	  void deleteProduct(int id);
}
