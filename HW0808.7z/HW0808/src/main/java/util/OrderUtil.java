package util;

import dao.HistoryDao;
import model.HistoryOrder;
import model.Product;
import service.HistoryService;
import service.ProductUserService;
import service.impl.ProductUserServiceImpl;

import java.util.List;

import javax.swing.JTextArea;
import javax.swing.table.DefaultTableModel;

public class OrderUtil {


    public static void showLatestOrderToTextArea(HistoryService service, String username, JTextArea area) {
        HistoryOrder latest = service.getLatestOrderByUser(username);
        if (latest == null) {
        	area.setText("查無訂單紀錄");
            return;
        }

        String summary = latest.getOrderSummary();
        int total = calcTotal(summary);
        summary += "\n" + "總金額：" + total;
        area.setText(summary);
    }


    public static int calcTotal(String summary) {
        int sum = 0;
        for (String line : summary.split("\\R")) {
            int idx = line.lastIndexOf("總計:");
            if (idx != -1) {
                try {
                    sum += Integer.parseInt(line.substring(idx + 3).trim());
                } catch (NumberFormatException ignore) {}
            }
        }
        return sum;
    }
    
    

}