package util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import javax.swing.JLabel;
import model.Member;



public class Tool {

	public static void writeFile(String path, Object obj) {
	    try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(path))) {
	        oos.writeObject(obj);
	    } catch (IOException e) { e.printStackTrace(); }
	}
	
	public static void saveFile(Object object,String fileName)
	{
		try {
			FileOutputStream fos = new FileOutputStream(fileName);
			ObjectOutputStream oos = new ObjectOutputStream(fos);
			oos.writeObject(object);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static Object readFile(String fileName)
	{
		Object object = null;
		try {
			FileInputStream fis = new FileInputStream(fileName);
			ObjectInputStream ois = new ObjectInputStream(fis);
			object= ois.readObject();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return object;
	}
	public static void displayWelcomeMessage(JLabel label) {
	    Member m = (Member) Tool.readFile("member.txt");
	    if (m != null) {
	    	label.setText(m.getName() + "歡迎您");
	    } else {
	    	label.setText("歡迎您");
	    }
	}

}
