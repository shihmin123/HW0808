package util;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.JLabel;
import javax.swing.Timer;

public class TimeUtil {

    private static final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	
    public static void startClock(JLabel label) {
        Timer timer = new Timer(100, e -> {
            String currentTime = sdf.format(new Date());
            label.setText(currentTime);
        });
        timer.start();
    }
	
	
	
}
