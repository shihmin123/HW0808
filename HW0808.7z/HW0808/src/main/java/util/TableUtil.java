package util;

import java.awt.Component;
import java.util.List;

import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;

import model.HistoryOrder;
import model.Member;
import model.Product;
import service.HistoryService;
import service.MemberService;
import service.ProductUserService;
import service.impl.ProductUserServiceImpl;

public class TableUtil {


    public static void loadMemberDataToTable(DefaultTableModel tableModel, MemberService memberService) {
        tableModel.setRowCount(0);
        List<Member> members = memberService.getAllMembers();
        for (Member m : members) {
            Object[] row = {
                m.getId(),
                m.getName(),
                m.getUsername(),
                m.getPassword(),
                m.getAddress(),
                m.getPhone(),
                m.getRole()
            };
            tableModel.addRow(row);
        }
    }


    public static void loadProductDataToTable(DefaultTableModel tableModel, ProductUserService productService) {
        tableModel.setRowCount(0);
        List<Product> products = productService.getAllProducts();
        for (Product p : products) {
            Object[] row = {
                p.getId(),
                p.getProductNo(),
                p.getProductName(),
                p.getProductPrice()
            };
            tableModel.addRow(row);
        }
    }


    public static void memberBuyToTable(DefaultTableModel tableModel, ProductUserService productService) {
        tableModel.setRowCount(0);
        List<Product> products = productService.getAllProducts();
        for (Product p : products) {
            Object[] row = {
                p.getProductNo(),
                p.getProductName(),
                p.getProductPrice()
            };
            tableModel.addRow(row);
        }
    }


    public static void loadHistoryOrderDataToTable(DefaultTableModel model, Member user, HistoryService historyService) {
        model.setRowCount(0);
        List<HistoryOrder> list = "admin".equalsIgnoreCase(user.getRole())
                ? historyService.getAllOrders()
                : historyService.getOrdersByUser(user.getUsername());

        for (HistoryOrder o : list) {
            int total = calcTotal(o.getOrderSummary());
            model.addRow(new Object[]{
                    o.getId(),
                    o.getUserName(),
                    o.getOrderTime(),
                    o.getOrderSummary(),
                    total
            });
        }
    }


    public static int calcTotal(String summary) {
        int sum = 0;
        for (String line : summary.split("\\R")) {
            int idx = line.lastIndexOf("總計:");
            if (idx != -1) {
                try {
                    sum += Integer.parseInt(line.substring(idx + 3).trim());
                } catch (NumberFormatException ignore) {}
            }
        }
        return sum;
    }


    public static void adjustTableColumnWidths(JTable table) {
        table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);

        for (int column = 0; column < table.getColumnCount(); column++) {
            int preferredWidth = 50;
            int maxWidth = 300;

            TableCellRenderer headerRenderer = table.getTableHeader().getDefaultRenderer();
            Component headerComp = headerRenderer.getTableCellRendererComponent(
                    table, table.getColumnName(column), false, false, 0, column);
            preferredWidth = Math.max(preferredWidth, headerComp.getPreferredSize().width);

            for (int row = 0; row < table.getRowCount(); row++) {
                TableCellRenderer cellRenderer = table.getCellRenderer(row, column);
                Component comp = table.prepareRenderer(cellRenderer, row, column);
                preferredWidth = Math.max(preferredWidth, comp.getPreferredSize().width);
            }

            preferredWidth += 20;
            preferredWidth = Math.min(preferredWidth, maxWidth);
            table.getColumnModel().getColumn(column).setPreferredWidth(preferredWidth);
        }
    }
    public static void loadProductDataToTable(DefaultTableModel model) {
        model.setRowCount(0);

        ProductUserService productService = new ProductUserServiceImpl();
        List<Product> products = productService.getAllProducts();

        for (Product product : products) {
            Object[] rowData = {
                product.getId(),
                product.getProductNo(),
                product.getProductName(),
                product.getProductPrice()
            };
            model.addRow(rowData);
        }
    }
    public static void loadProductDataToTableThreeColumns(DefaultTableModel tableModel, ProductUserService productService) {
        tableModel.setRowCount(0);
        List<Product> products = productService.getAllProducts();
        for (Product p : products) {
            Object[] row = {
                p.getProductNo(),
                p.getProductName(),
                p.getProductPrice()
            };
            tableModel.addRow(row);
        }
    }
    public static void loadHistoryOrderDataToTableByUsername(DefaultTableModel model, String username, HistoryService historyService) {
        model.setRowCount(0);  
        List<HistoryOrder> orders = historyService.getOrdersByUser(username);
        for (HistoryOrder order : orders) {
            Object[] row = {
                order.getId(),
                order.getUserName(),             
                order.getOrderTime(),
                order.getOrderSummary()

            };
            model.addRow(row);
        }
    }
    public static void loadAllHistoryOrdersToTable(DefaultTableModel model, HistoryService historyService) {
        model.setRowCount(0); // 清空表格內容
        List<HistoryOrder> orders = historyService.getAllOrders();
        for (HistoryOrder order : orders) {
            int total = TableUtil.calcTotal(order.getOrderSummary()); // 計算總金額
            Object[] row = {
                order.getId(),
                order.getUserName(),
                order.getOrderTime(),
                order.getOrderSummary(),
                total
            };
            model.addRow(row);
        }
    }
    
}